select modelo
     , ano
     , chassis
     , tipoCambio
     , fabricante
  from Veiculo
 order by modelo