select idVenda
     , valorVenda
     , dataVenda
  from VendaVeiculo
  where idCliente = idCarro.idCliente
  order by idVenda
